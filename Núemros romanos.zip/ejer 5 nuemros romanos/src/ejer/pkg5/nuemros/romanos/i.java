/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejer.pkg5.nuemros.romanos;

/**
 *
 * @author B11
 */
class i<T0, T1> {
    
}
