
import java.util.Scanner;

public class ConvertidorBinario {

    public static void main(String[] args) {
        long num, ax, dig, dc;
        int exp;
        boolean esReg;
        Scanner sc = new Scanner(System.in);
        do {
            System.out.print("INGRESE EL NUMERO BINARIO: ");
            num = sc.nextLong();
            esReg = true;
            ax = num;
            while (ax != 0) {
                dig = ax % 10;
                if (dig != 0 && dig != 1) {
                    esReg = false;
                }
                ax = ax / 10;
            }
        } while (!esReg);
        exp = 0;
        dc = 0;
        while (num != 0) {
            dig = num % 10;
            dc = dc + dig * (int) Math.pow(2, exp);
            exp++;
            num = num / 10;
        }
        System.out.println("NUMERO DECIMAL: " + dc);
    }
}






