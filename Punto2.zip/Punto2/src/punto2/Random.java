
package punto2;


public class Random {
    
}
