
package punto2;
import java.util.Random;
public class Punto2 {

    public static void main(String[] args) {
 
        llenarArrayAleatorio(1,7,10);
        
    }
    public static int [] llenarArrayAleatorio(int from, int to, int rang){
        int[] numeros = new int[rang];                                                                             
        Random rnd = new Random();
        for (int i = 0; i < numeros.length; i++) {
             numeros[i] = rnd.nextInt(to - from + 1) + from;       
             System.out.print(numeros[i]);
             System.out.println( "" );
        }

        return numeros;
}

    
    
}
