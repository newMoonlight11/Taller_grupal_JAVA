
package primer.ejercicio;
import java.util.*;
import javax.swing.JOptionPane;
public class PrimerEjercicio {

    public static void main(String[] args) {
    //se definen las variables
    Scanner sc = new Scanner(System.in);
    String[] name = new String[20];
    double[] salary = new double[20];
    String nameM;
    double salaryM;
    int i = 0;
    //ingreso de datos    
    JOptionPane.showMessageDialog(null, "Ingresa el nombre y el salario de cada empleado");  
    System.out.print("Nombre " + (i + 1) + ": ");
    name[i] = sc.nextLine();
    System.out.print("Salario: ");
    salary[i] = sc.nextDouble();
    
    //tomar los primeros datos como los mayores
    nameM=name[i];
    salaryM=salary[i];
    
    
    for (i = 1; i < name.length; i++) {
            sc.nextLine(); 
            System.out.print("Empleado " + (i + 1) + ": ");
            name[i] = sc.nextLine();
            System.out.print("Sueldo: ");
            salary[i] = sc.nextDouble();
            if (salary[i] > salaryM) {
                salaryM = salary[i];
                nameM = name[i];
            }
        }
    JOptionPane.showMessageDialog(null, "Nombre del empleado con mayor sueldo: " + nameM);
    JOptionPane.showMessageDialog(null, "Mayor sueldo: " + salaryM);                                
    }
    
}
