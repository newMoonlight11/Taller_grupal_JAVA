package tres;
import java.util.Scanner;

public class Tres {

    static String quitarPalabra(String text) {
        return (text.trim()).substring(0,(text.trim()).lastIndexOf(" "));
    }
    
    public static void main(String[] args) {
        Scanner scan= new Scanner(System.in);
        String text= scan.nextLine();
        System.out.println(quitarPalabra(text));
    }
    
}
